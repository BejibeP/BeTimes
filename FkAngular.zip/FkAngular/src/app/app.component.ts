import { Component, OnInit } from '@angular/core';
import { DisplayService } from './services/display/display.service';
import { TranslateService } from '@ngx-translate/core';
import * as $ from 'jquery';
import { ActivatedRoute, Event, NavigationEnd, Params, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { ChangelogService } from './services/changelog/changelog.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'bouygue-front';
  menuIsExtend = true;
  showStoreTierceComponent: boolean = false;
  showViewerComponent:boolean=false;
  showGediNormal:boolean=true;
  showChangelogComponent:boolean=false;

  metaToStoreComponent = {
    'callbackuri': null,
    'transactionid': null
  }

  fieldsToStoreComponent = {};

  documentToViewerComponent = {
    'docId': null,
    'fcId': null,
    'orgId': null
  };

  constructor(
    private messageService: MessageService,
    private displayService: DisplayService,
    private changelogService: ChangelogService,
    private router: Router,
    private route: ActivatedRoute,
    private translate: TranslateService) {

    this.translate.setDefaultLang("fr_FR");
    this.translate.use("fr_FR");

    let gediVersion = localStorage.getItem('gedi_version');
    if (!gediVersion ||  gediVersion == '1.0.7') {
      localStorage.removeItem('columns_');
      localStorage.setItem('gedi_version', '1.0.8');
    }
  }

  ngOnInit(): void {
    let that = this;
    this.router.events.subscribe((e: Event) => {
      if (e instanceof NavigationEnd && e.url != undefined) {
        let url = e.url;
        if ((url.toLocaleLowerCase()=='/store')||url.toLocaleLowerCase().includes('/store?')) {
          that.showGediNormal = false;
          that.showViewerComponent = false;
          // afficher composant tiers
          if (!url.toLocaleLowerCase().includes('callbackuri') || !url.toLocaleLowerCase().includes('transactionid')) {
            if (!url.toLocaleLowerCase().includes('iss=') && !url.toLocaleLowerCase().includes('session_state=')) {
              // ça ne devrait pas afficher le msg d'erreur quand la 1ere redirection d'IRIS contient queryString
              // 1. en testbed : 'iss='
              // 2. en prod : 'session_state='
              that.messageService.add({ severity: 'error', summary: 'callbackUri, transactionId manquent', detail: 'L\'URL de callback et l\'identifiant de la transaction sont nécessaires au chargement du composant' });
              // !!! iris étape 1 code, 2 token, si l'on affiche pas le composant, iris va s'arreter sans appeler endpoint token
              // donc iris dans tous les ENV ne vient pas ici tant que IRIS autorisation n'est pas fini
              that.showStoreTierceComponent = false;  
            } else {
              that.showStoreTierceComponent = true;
            }
          } else {
            that.showStoreTierceComponent = true;
          }
        } else if ((url.toLocaleLowerCase()=='/viewer')||url.toLocaleLowerCase().includes('/viewer?')) {
          that.showGediNormal = false;
          // afficher composant tiers
          if (!url.toLocaleLowerCase().includes('docid') || !url.toLocaleLowerCase().includes('fcid') || !url.toLocaleLowerCase().includes('orgid')) {
            that.messageService.add({ severity: 'error', summary: 'docId, fcId, orgId manquent', detail: 'L\'Identifiant du document, l\'identifiant de l\'armoire et l\'identifiant de l\'organisation sont nécessaires au chargement du composant' });
            that.showStoreTierceComponent = false;
            that.showViewerComponent = false;
          } else {
            that.showStoreTierceComponent = false;
            that.showViewerComponent = true;
          }
        } else {
          // afficher gedi normal
          that.showGediNormal = true;
          that.showStoreTierceComponent = false;
          that.showViewerComponent = false;
        }

        if((url.toLocaleLowerCase() !== '/login')) {
          this.changelogService.activeChangelog$.subscribe(activeChangelog => {
            this.showChangelogComponent = activeChangelog;
          });
          this.changelogService.showChangelog();
        }
        //console.log('show gedi : ' + that.showGediNormal);
        //console.log('show tierce : ' + that.showStoreTierceComponent);
      }
    });

    // récupérer query string dans un Objet : metaToStoreComponent/fieldsToStoreComponent
    this.route.queryParams
      .subscribe(params => {
        let that = this;
        if (Object.keys(params).length != 0) {
          let paramsLower = this.toLower(params);
          let paramsUpper = this.toUpper(params);
          that.metaToStoreComponent.callbackuri = paramsLower.callbackuri;
          that.metaToStoreComponent.transactionid = paramsLower.transactionid;

          that.fieldsToStoreComponent = paramsUpper;
          delete that.fieldsToStoreComponent["CALLBACKURI"];
          delete that.fieldsToStoreComponent["TRANSACTIONID"];

          that.documentToViewerComponent.docId = paramsLower.docid;
          that.documentToViewerComponent.fcId = paramsLower.fcid;
          that.documentToViewerComponent.orgId = paramsLower.orgid;

        }
      });
  }

  // faire minuscrite les clés d'un tabeau
  toLower(params: Params): Params {
    const lowerParams: Params = {};
    for (const key in params) {
        lowerParams[key.toLowerCase()] = params[key];
    }

    return lowerParams;
}

// faire majuscule les clés d'un tabeau
toUpper(params: Params): Params {
  const upperParams: Params = {};
  for (const key in params) {
    upperParams[key.toUpperCase()] = params[key];
  }

  return upperParams;
}

  extendMenu() {
    // if (!this.menuIsExtend) {
    //   console.log('mouse over menu');
    //   $(".app_page").animate({ 'margin-left': '15%', width: '85%' });
    //   $(".app_menu").animate({ 'margin-left': '0' });
    //   this.menuIsExtend = true;
    // }
  }

  retractMenu() {
    // if (this.menuIsExtend) {
    //   console.log('mouse over page');
    //   $('.app_page').animate({ width: '98%', 'margin-left': '2%' });
    //   $(".app_menu").animate({ 'margin-left': '-13%' });
    //   this.menuIsExtend = false;
    // }
  }
}
