import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChangelogComponent } from './changelog.component';
import { DialogModule } from 'primeng/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { FormsModule } from '@angular/forms';

export const routerConfig = [
  {
    path: '',
    component: ChangelogComponent,
  },
];
@NgModule({
  declarations: [ChangelogComponent],  
  imports: [
    CommonModule,
    FormsModule,
    DialogModule,
    CheckboxModule,
  ],
  exports: [
    ChangelogComponent
  ]
})
export class ChangelogModule { }
