import { Component, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ChangelogSection } from 'src/app/services/changelog/changelog.models';
import { ChangelogService } from 'src/app/services/changelog/changelog.service';

@Component({
  selector: 'app-changelog',
  templateUrl: './changelog.component.html',
  styleUrls: ['./changelog.component.scss']
})
export class ChangelogComponent {
  
  @ViewChild('dynamicSection', { static: false }) dynamicSectionContainer: ElementRef<HTMLElement>;

  changelogVisible: boolean = true;
  changelogName: string = '';
  keepChangelog: boolean = true;
  
  sections: ChangelogSection[];

  nbSections: number = 0;
  currentSectionIndex: number;

  constructor(private sanitizer: DomSanitizer, private renderer: Renderer2, private changelogService: ChangelogService) { }

  async loadChangelog() {
    this.changelogName = this.changelogService.metadata?.name ?? 'Changelog';

    this.sections = await this.changelogService.loadChangelogContentAsync();
    this.nbSections = this.sections.length;
    this.loadSection(0);
  }

  destroyChangelog() {
    this.sections = [];
    this.nbSections = 0;
    this.currentSectionIndex = 0;
  }

  closeChangelog() {
    this.changelogVisible = false;
    if(!this.keepChangelog) {
      this.changelogService.disableChangelog();
    } else {
      this.changelogService.disableChangelogForSession();
    }
  }

  previous() {
    if(this.currentSectionIndex == 0) {
      return;
    }
    this.loadSection(this.currentSectionIndex - 1);
  }

  next() {
    if(this.currentSectionIndex == (this.nbSections - 1)) {
      return;
    }
    this.loadSection(this.currentSectionIndex + 1);
  }

  loadSection(sectionIndex: number) {
    if(sectionIndex < 0 || sectionIndex > (this.nbSections - 1)) {
      return;
    }
    this.currentSectionIndex = sectionIndex;

    if(!this.dynamicSectionContainer) {
      return;
    }

    let unsafeHTML = this.sections[sectionIndex].content;
    const elem = this.dynamicSectionContainer.nativeElement;

    this.renderer.setProperty(elem, 'innerHTML', unsafeHTML);      
  }

}
