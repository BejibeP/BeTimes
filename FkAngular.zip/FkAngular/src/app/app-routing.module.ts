import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogguardGuard } from './services/guard/logguard.guard';
import { Page401Component } from './page/page401/page401.component';
import { LogoutComponent } from './actions/logout/logout.component';
import { StoreLogguardGuard } from './services/guard/storelogguard.guard';


export const routeConfig: Routes = [

{
    path: '',
    pathMatch: 'full',
    loadChildren: () => import('./page/login/login.module').then(m => m.LoginModule),
    canActivate: []
},
{
    path: 'login',
    loadChildren: () => import('./page/login/login.module').then(m => m.LoginModule),
    title: 'login',
    canActivate: []
},
{
  path: 'search',
  loadChildren: () => import('./page/search/search.module').then(m => m.SearchModule),
  title: 'search',
  canActivate: [LogguardGuard]
},
{
  path: 'home',
  loadChildren: () => import('./page/home/home.module').then(m => m.HomeModule),
  title: 'home',
  canActivate: [LogguardGuard]
},
{
  path: 'admin',
  loadChildren: () => import('./page/admin/admin.module').then(m => m.AdminModule),
  title: 'admin',
  canActivate: [LogguardGuard]
},
{
  path: 'signatures',
  loadChildren: () => import('./page/signatures/signatures.module').then(m => m.SignaturesModule),
  title: 'signatures',
  canActivate: [LogguardGuard]
},
{
  path: 'tasks',
  loadChildren: () => import('./page/tasks/tasks.module').then(m => m.TasksModule),
  title: 'tasks',
  canActivate: [LogguardGuard]
},
{
  path: 'password',
  loadChildren: () => import('./page/password/password.module').then(m => m.PasswordModule),
  title: 'password',
  canActivate: [LogguardGuard]
},
{
  path: 'store-center',
  loadChildren: () => import('./page/store-center/store-center.module').then(m => m.StoreCenterModule),
  title: 'store-center',
  canActivate: [LogguardGuard]
},
{
  path: 'store',
  loadChildren: () => import('./page/store/store.module').then(m => m.StoreModule),
  title: 'store',
  canActivate: [StoreLogguardGuard]
},
{
  path: 'viewer',
  loadChildren: () => import('./page/viewer/viewer.module').then(m => m.ViewerModule),
  title: 'viewer',
  canActivate: [StoreLogguardGuard]
},
{
  path: 'changelog',
  loadChildren: () => import('./page/changelog/changelog.module').then(m => m.ChangelogModule),
  title: 'changelog',
  canActivate: [LogguardGuard]
},
{
  path: 'logout',
  component: LogoutComponent
},
{
  path: 'page401',
  component: Page401Component
},
{
  path: '**',
  loadChildren: () => import('./page/search/search.module').then(m => m.SearchModule),
  title: 'search',
  canActivate: [LogguardGuard]
}
]

@NgModule({
  imports: [RouterModule.forRoot(routeConfig, {onSameUrlNavigation: 'reload'})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
