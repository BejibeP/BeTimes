import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { ChangelogMetadata, ChangelogSection } from './changelog.models';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChangelogService {

    static readonly metadataPath = 'assets/changelog/changelog.json';
    static readonly contentPath = 'assets/changelog/changelog.html';
    static readonly disabledChangelogKey = 'disabled-changelog';

    metadata:ChangelogMetadata = null;

    activeChangelog$ = new BehaviorSubject<boolean>(false);

    constructor(private http: HttpClient, private sanitizer: DomSanitizer) {

    }
    
    // Charge les metadonnées du changelog actif
    public async loadMetadatasAsync(): Promise<ChangelogMetadata> {
        try {            
            let meta = await this.http.get(ChangelogService.metadataPath).toPromise() as ChangelogMetadata;
            if(!meta) {
                throw new Error("échec de la récuperation du ficher de metadonnées du changelog");
            }
            meta.validFrom = new Date(meta.validFrom);
            meta.validUntil = new Date(meta.validUntil);
            return meta;
        }
        catch (e) {
            console.log("La récupération des métadonnées a échoué", e);
            throw e;
        }
    }

    // Charge les metadonnées du changelog actif
    public async loadChangelogContentAsync(): Promise<ChangelogSection[]> {
        try {            
            let rawHtml = await this.http.get(ChangelogService.contentPath, {responseType: 'text'}).toPromise();
            if(!rawHtml) {
                throw new Error("échec de la récuperation du ficher de metadonnées du changelog");
            };
            const parser = new DOMParser();
            const doc = parser.parseFromString(rawHtml, 'text/html');
            const sections = Array.from(doc.querySelectorAll('section')).map((section: HTMLElement) => {
                const id = section.id;
                const content = section.outerHTML;
                return {id, content} as ChangelogSection;
            });
            return sections;
        }
        catch (e) {
            console.log("La récupération des métadonnées a échoué", e);
            throw e;
        }
    }

    public showChangelog() {
        if(!this.metadata) {
            this.loadMetadatasAsync().then(res => {
                this.metadata = res;
                this.activeChangelog$.next(this.isChangelogActive());
            });
        } else {
            this.activeChangelog$.next(this.isChangelogActive());
        }
    }

    private isChangelogActive(): boolean {
        if(!this.metadata) {
            return false;
        }

        let currentDate = new Date();
        let isValidPeriod = this.metadata.validFrom <= currentDate && currentDate <= this.metadata.validUntil;

        let disabledChangelog = localStorage.getItem(ChangelogService.disabledChangelogKey);
        let disabledChangelogForSession = sessionStorage.getItem(ChangelogService.disabledChangelogKey);

        if(disabledChangelog == this.metadata.name || disabledChangelogForSession == this.metadata.name || !isValidPeriod) {
            return false;
        }

        return true;
    }

    disableChangelog() {
        if(!this.metadata) {
            return;
        }
        localStorage.removeItem(ChangelogService.disabledChangelogKey);
        sessionStorage.removeItem(ChangelogService.disabledChangelogKey);
        localStorage.setItem(ChangelogService.disabledChangelogKey, this.metadata.name);
    }

    disableChangelogForSession() {
        if(!this.metadata) {
            return;
        }
        localStorage.removeItem(ChangelogService.disabledChangelogKey);
        sessionStorage.removeItem(ChangelogService.disabledChangelogKey);
        sessionStorage.setItem(ChangelogService.disabledChangelogKey, this.metadata.name);
    }

    safe(url) {
        if (typeof url == 'string') {    
            return this.sanitizer.bypassSecurityTrustResourceUrl(url);
        } else {
            return url;
        }
    }

    safeLink(url) {
        return this.sanitizer.bypassSecurityTrustUrl(url);
    }

    safeHtml(html) {
        return this.sanitizer.bypassSecurityTrustHtml(html);
    }

}