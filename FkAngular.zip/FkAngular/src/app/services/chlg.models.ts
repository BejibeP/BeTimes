export interface ChangelogMetadata {
    name: string;
    validFrom: Date;
    validUntil: Date;
}

export interface ChangelogSection {
    id: string;
    content: string;
}