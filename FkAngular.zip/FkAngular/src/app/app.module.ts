import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import {HttpClientModule, HttpClient} from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ConfigurationService } from './services/configuration/configuration.service';
import { MenuModule } from './all-time/menu/menu.module';
import {SharedModule} from  "./shared/shared.module" ;
import {ToastModule} from 'primeng/toast';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { MessageService } from 'primeng/api';
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import {SplitButtonModule} from 'primeng/splitbutton';
import {ProgressSpinnerModule} from 'primeng/progressspinner';
import {BlockUIModule} from 'primeng/blockui';
import { Page401Component } from './page/page401/page401.component';
import { LogoutComponent } from './actions/logout/logout.component';
import {CheckboxModule} from 'primeng/checkbox';
import { UrlSerializer } from '@angular/router';
import { LowerCaseUrlSerializer } from './classes/LowerCaseUrlSerializer';
import { StoreModule } from './page/store/store.module';
import { ViewerModule } from './page/viewer/viewer.module';
import { ChangelogModule } from './page/changelog/changelog.module';



export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http, "./assets/lang/", "-lang.json");
}

export function startupServiceFactory(configService: ConfigurationService): Function {
  return () => configService.init();
}
@NgModule({
  declarations: [
    AppComponent,
    Page401Component,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    MenuModule,
    HttpClientModule,
    AppRoutingModule,
    SharedModule,
    MessagesModule,
    MessageModule,
    CheckboxModule,
    ToastModule,
    BrowserAnimationsModule,
    ProgressSpinnerModule,
    BlockUIModule,
    StoreModule,
    ViewerModule,
    ChangelogModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  exports: [
    TranslateModule,    
    SplitButtonModule,

  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: startupServiceFactory,
      deps: [ConfigurationService],
      multi: true
    },
    {
      provide: UrlSerializer,
      useClass: LowerCaseUrlSerializer
    },
    MessageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
